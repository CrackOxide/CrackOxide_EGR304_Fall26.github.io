/*
 * arm_test.h
 * Stand-alone hardware verification mode (MODE_TEST).
 * Uses only the debug button BTN_DBG and the debug LED DS2.
 */
#ifndef ARM_TEST_H
#define ARM_TEST_H

void Test_Enter(void);
void Test_Task1ms(void);

#endif /* ARM_TEST_H */

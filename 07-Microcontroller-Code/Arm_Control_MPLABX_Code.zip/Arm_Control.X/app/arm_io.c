/*
 * arm_io.c
 * Board-level helpers for the Arm Motion Control board (YR).
 *
 * Pins (set up by MCC in pins.c):
 *   RC4 MOT_FWD  -> PWM1 output 1 -> FAN8100N FORWARDA
 *   RC5 MOT_REV  -> PWM1 output 2 -> FAN8100N REVERSEA
 *   RD0 SAFE_OK  in   (J3 pin 1)    RD1 RUN_REQ  in  (J3 pin 2)
 *   RD2 GRIP_CMD out  (J3 pin 3)    RD3 OBJ_HELD in  (J3 pin 4)
 *   RD4 ARM_IN_POS out(J3 pin 5)    RA1 SPEED_SET analog (J3 pin 6)
 *   RE0 LED_DBG  out                RE1 BTN_DBG  in, weak pull-up
 */
#include "../mcc_generated_files/system/system.h"
#include "arm_config.h"
#include "arm_io.h"

/* ================================================================== */
/* 1 ms time base                                                      */
/* ================================================================== */
/* TMR0 runs free in 16-bit mode from FOSC/4 = 16 MHz with a 1:64
 * prescaler, so it counts at 250 kHz (250 counts per ms) and wraps
 * every 262 ms. Tick_Update() turns the counts into milliseconds, so
 * no interrupt is needed and a long task does not lose time.         */
#define TICKS_PER_MS 250u

static uint32_t tick_ms;
static uint16_t tick_last;
static uint16_t tick_acc;

static uint16_t tmr0_read(void)
{
    uint8_t lo = TMR0L;               /* reading TMR0L latches TMR0H  */
    uint8_t hi = TMR0H;
    return (uint16_t)(((uint16_t)hi << 8) | lo);
}

void Tick_Init(void)
{
    T0CON0 = 0x00;                    /* stop while configuring       */
    T0CON1 = 0x46;                    /* CS = FOSC/4, sync, 1:64      */
    TMR0H  = 0;
    TMR0L  = 0;
    T0CON0 = 0x90;                    /* EN = 1, MD16 = 1, 1:1 post   */
    tick_ms = 0;
    tick_acc = 0;
    tick_last = tmr0_read();
}

void Tick_Update(void)
{
    uint16_t now = tmr0_read();
    tick_acc += (uint16_t)(now - tick_last);  /* wraps correctly      */
    tick_last = now;
    while (tick_acc >= TICKS_PER_MS)
    {
        tick_acc -= TICKS_PER_MS;
        tick_ms++;
    }
}

uint32_t Tick_Ms(void)
{
    return tick_ms;
}

/* ================================================================== */
/* Motor                                                               */
/* ================================================================== */
/* Rule from the Software Proposal: only one PWM output is non-zero at
 * a time. Before the direction changes, both outputs are held at 0 %
 * for MOTOR_REVERSE_GAP_MS so the motor can coast down.              */
static motor_dir_t act_dir = MOTOR_STOP;
static uint8_t     act_duty = 0;
static motor_dir_t req_dir = MOTOR_STOP;
static uint8_t     req_duty = 0;
static uint16_t    gap_ms = 0;

static void pwm_apply(motor_dir_t dir, uint8_t duty)
{
    uint16_t reg;

    if (duty > 100u)
    {
        duty = 100u;
    }
    if (dir == MOTOR_STOP)
    {
        duty = 0u;
    }
    reg = (uint16_t)(((uint32_t)duty * PWM_PERIOD_COUNTS) / 100UL);

    if (dir == MOTOR_FWD)
    {
        PWM1_16BIT_SetSlice1Output2DutyCycleRegister(0);
        PWM1_16BIT_SetSlice1Output1DutyCycleRegister(reg);
    }
    else if (dir == MOTOR_REV)
    {
        PWM1_16BIT_SetSlice1Output1DutyCycleRegister(0);
        PWM1_16BIT_SetSlice1Output2DutyCycleRegister(reg);
    }
    else
    {
        PWM1_16BIT_SetSlice1Output1DutyCycleRegister(0);
        PWM1_16BIT_SetSlice1Output2DutyCycleRegister(0);
    }
    PWM1_16BIT_LoadBufferRegisters();  /* both load at the next period */

    act_dir  = (duty == 0u) ? MOTOR_STOP : dir;
    act_duty = duty;
}

void Motor_Init(void)
{
    req_dir = MOTOR_STOP;
    req_duty = 0;
    gap_ms = 0;
    pwm_apply(MOTOR_STOP, 0);
}

void Motor_Stop(void)
{
    req_dir = MOTOR_STOP;
    req_duty = 0;
    if (act_dir != MOTOR_STOP)
    {
        gap_ms = MOTOR_REVERSE_GAP_MS;   /* let it coast before restart */
    }
    pwm_apply(MOTOR_STOP, 0);
}

void Motor_Run(motor_dir_t dir, uint8_t duty_pct)
{
    if ((dir == MOTOR_STOP) || (duty_pct == 0u))
    {
        Motor_Stop();
        return;
    }

    req_dir = dir;
    req_duty = duty_pct;

    if (act_dir == dir)
    {
        pwm_apply(dir, duty_pct);        /* same direction: new duty    */
    }
    else if (act_dir == MOTOR_STOP)
    {
        if (gap_ms == 0u)
        {
            pwm_apply(dir, duty_pct);    /* stopped long enough         */
        }
        /* else: Motor_Task1ms() starts it when the gap ends          */
    }
    else
    {
        pwm_apply(MOTOR_STOP, 0);        /* reversal: off first         */
        gap_ms = MOTOR_REVERSE_GAP_MS;
    }
}

void Motor_Task1ms(void)
{
    if (gap_ms > 0u)
    {
        gap_ms--;
        if ((gap_ms == 0u) && (req_dir != MOTOR_STOP))
        {
            pwm_apply(req_dir, req_duty);
        }
    }
}

motor_dir_t Motor_Dir(void)
{
    return act_dir;
}

uint8_t Motor_Duty(void)
{
    return act_duty;
}

/* ================================================================== */
/* Team link                                                           */
/* ================================================================== */
/* Every input has a 10 k pull-down, so an unplugged wire reads 0.
 * RUN_REQ and OBJ_HELD must be stable for LINK_DEBOUNCE_MS to change.
 * SAFE_OK = 0 is accepted at once (stop must not wait); SAFE_OK = 1
 * must be stable for LINK_DEBOUNCE_MS before it counts.               */
typedef struct
{
    bool    state;
    uint8_t count;
} debounce_t;

static debounce_t db_safe, db_run, db_held;
static bool out_grip, out_inpos;

static void debounce(debounce_t *d, bool raw)
{
    if (raw == d->state)
    {
        d->count = 0;
    }
    else if (++d->count >= LINK_DEBOUNCE_MS)
    {
        d->state = raw;
        d->count = 0;
    }
}

uint8_t Link_RawInputs(void)
{
    uint8_t v = 0;
    if (SAFE_OK_GetValue())
    {
        v |= 0x01u;
    }
    if (RUN_REQ_GetValue())
    {
        v |= 0x02u;
    }
    if (OBJ_HELD_GetValue())
    {
        v |= 0x04u;
    }
    return v;
}

void Link_Init(void)
{
    Link_SetGripCmd(false);
    Link_SetArmInPos(false);
    db_safe.state = false;
    db_safe.count = 0;
    db_run.state  = false;
    db_run.count  = 0;
    db_held.state = false;
    db_held.count = 0;
}

void Link_Task1ms(void)
{
    uint8_t raw = Link_RawInputs();

    if ((raw & 0x01u) == 0u)
    {
        db_safe.state = false;           /* stop immediately            */
        db_safe.count = 0;
    }
    else
    {
        debounce(&db_safe, true);
    }
    debounce(&db_run,  (raw & 0x02u) != 0u);
    debounce(&db_held, (raw & 0x04u) != 0u);
}

bool Link_SafeOk(void)  { return db_safe.state; }
bool Link_RunReq(void)  { return db_run.state;  }
bool Link_ObjHeld(void) { return db_held.state; }
bool Link_GripCmd(void) { return out_grip;  }
bool Link_ArmInPos(void){ return out_inpos; }

void Link_SetGripCmd(bool on)
{
    out_grip = on;
    if (on)
    {
        GRIP_CMD_SetHigh();
    }
    else
    {
        GRIP_CMD_SetLow();
    }
}

void Link_SetArmInPos(bool on)
{
    out_inpos = on;
    if (on)
    {
        ARM_IN_POS_SetHigh();
    }
    else
    {
        ARM_IN_POS_SetLow();
    }
}

/* ================================================================== */
/* SPEED_SET                                                           */
/* ================================================================== */
/* 12-bit ADCC, VREF = VDD = 3.3 V on the Curiosity Nano.              */
static uint16_t spd_buf[SPEED_AVG_SAMPLES];
static uint8_t  spd_idx;
static uint32_t spd_sum;
static uint8_t  spd_timer;

uint16_t Speed_ReadNow(void)
{
    adc_result_t r = ADC_ChannelSelectAndConvert(ADC_CHANNEL_ANA1);
    if (r < 0)
    {
        r = 0;
    }
    if (r > 4095)
    {
        r = 4095;
    }
    return (uint16_t)r;
}

void Speed_Init(void)
{
    uint8_t i;
    uint16_t first = Speed_ReadNow();

    spd_sum = 0;
    for (i = 0; i < SPEED_AVG_SAMPLES; i++)
    {
        spd_buf[i] = first;
        spd_sum += first;
    }
    spd_idx = 0;
    spd_timer = 0;
}

void Speed_Task1ms(void)
{
    uint16_t s;

    if (++spd_timer < SPEED_SAMPLE_MS)
    {
        return;
    }
    spd_timer = 0;

    s = Speed_ReadNow();
    spd_sum -= spd_buf[spd_idx];
    spd_buf[spd_idx] = s;
    spd_sum += s;
    if (++spd_idx >= SPEED_AVG_SAMPLES)
    {
        spd_idx = 0;
    }
}

uint16_t Speed_Raw(void)
{
    return (uint16_t)(spd_sum / SPEED_AVG_SAMPLES);
}

uint16_t Speed_Millivolts(void)
{
    return (uint16_t)(((uint32_t)Speed_Raw() * 3300UL) / 4095UL);
}

uint8_t Speed_DutyPct(void)
{
    uint32_t span = (uint32_t)(DUTY_MAX_PCT - DUTY_MIN_PCT);
    return (uint8_t)(DUTY_MIN_PCT + ((uint32_t)Speed_Raw() * span) / 4095UL);
}

/* ================================================================== */
/* Debug button                                                        */
/* ================================================================== */
static bool        btn_state;        /* true = pressed (debounced)    */
static uint8_t     btn_count;
static uint16_t    btn_hold_ms;
static bool        btn_long_sent;
static btn_event_t btn_event = BTN_NONE;

void Button_Task1ms(void)
{
    bool raw = (BTN_DBG_GetValue() == 0);   /* active low             */

    if (raw == btn_state)
    {
        btn_count = 0;
    }
    else if (++btn_count >= BTN_DEBOUNCE_MS)
    {
        btn_count = 0;
        btn_state = raw;
        if (btn_state)
        {
            btn_hold_ms = 0;              /* just pressed               */
            btn_long_sent = false;
        }
        else if (!btn_long_sent)
        {
            btn_event = BTN_SHORT;        /* released before long       */
        }
    }

    if (btn_state && !btn_long_sent)
    {
        if (++btn_hold_ms >= BTN_LONG_MS)
        {
            btn_long_sent = true;
            btn_event = BTN_LONG;
        }
    }
}

btn_event_t Button_GetEvent(void)
{
    btn_event_t e = btn_event;
    btn_event = BTN_NONE;
    return e;
}

/* ================================================================== */
/* Debug LED                                                           */
/* ================================================================== */
static led_pattern_t led_pattern = LED_OFF;
static uint16_t      led_ms;

void Led_Set(led_pattern_t pattern)
{
    if (pattern != led_pattern)
    {
        led_pattern = pattern;
        led_ms = 0;
    }
}

void Led_Task1ms(void)
{
    bool on;

    if (++led_ms >= 1000u)
    {
        led_ms = 0;
    }

    switch (led_pattern)
    {
        case LED_ON:     on = true;                          break;
        case LED_SLOW:   on = (led_ms < 500u);               break;
        case LED_MEDIUM: on = ((led_ms % 250u) < 125u);      break;
        case LED_FAST:   on = ((led_ms % 100u) < 50u);       break;
        case LED_BLIP:   on = (led_ms < 60u);                break;
        default:         on = false;                         break;
    }

    if (on)
    {
        LED_DBG_SetHigh();
    }
    else
    {
        LED_DBG_SetLow();
    }
}

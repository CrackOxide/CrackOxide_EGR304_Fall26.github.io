# Arm Motion Control firmware (YR, Team 107)

PIC18F57Q43 Curiosity Nano, MPLAB X + XC8 + MCC Melody. Firmware 1.1 (no UART).

## Opening the project

1. Unzip, then in MPLAB X use **File → Open Project** and select the `Arm_Control.X` folder.
2. Press **Clean and Build**, then **Make and Program Device** with the Nano on USB.

## Files

| File | What it does |
|---|---|
| `main.c` | Start-up, mode choice, the 1 ms loop |
| `app/arm_config.h` | All tunable numbers (start-up mode, duties, move time, timeouts) |
| `app/arm_io.c/.h` | TMR0 1 ms time base, motor (FAN8100N), team link, SPEED_SET, button, LED |
| `app/arm_test.c/.h` | TEST mode: hardware verification with the button and DS2 |
| `app/arm_app.c/.h` | APP mode: team pick-and-place state machine |
| `mcc_generated_files/` | MCC drivers. `adc/src/adc.c` is a hand-written stand-in (see the note below) |

**Notes:**

* **ADC driver.** The original project zip had no `adc.c`, because MCC generation had failed. This project includes a stand-in with the same settings as the MCC ADCC setup: ADCRC clock, right-justified, VDD reference, ANA1. If you press **Generate** in MCC, MCC replaces it with its own file.
* **Timer.** TMR0 is set up directly in `arm_io.c`. Do not add TMR0 in MCC.
* **UART.** The firmware does not use the UART. The MCC configuration still contains UART1. To remove it, delete UART1 from Project Resources in MCC and press Generate.

## Choosing the mode

* `BOOT_MODE` in `app/arm_config.h` sets the start-up mode. The default is `MODE_TEST`.
* Holding BTN_DBG while the Nano powers up (plugging in USB) starts the other mode.

## TEST mode

TEST mode has two tests. **Hold BTN_DBG for 1.5 s** to stop the motor and switch between them.

### MOTOR test (at power-up)

| Action | Result |
|---|---|
| Short press while stopped | Motor turns forward: PWM on RC4, RC5 = 0, 60 % duty |
| Each later short press | Motor flips direction: PWM on RC5, RC4 = 0. Both outputs are off for 250 ms in between. |

| DS2 | Meaning |
|---|---|
| Slow blink (1 Hz) | Stopped |
| On | Forward |
| 4 Hz blink | Reverse |

Hardware Verification motor tests:

1. Press the button once. The motor turns one way.
2. Press again. The motor turns the other way.
3. Keep pressing. The direction changes on every pin change of RE1.

The PWM can be watched on J5 pin 1 (PWM1) and J5 pin 2 (PWM2).

SAFE_OK is ignored in TEST mode, so the board can be tested alone. Set `TEST_OBEYS_SAFE_OK` to 1 to change that.

### LINK test (8-pin ribbon check)

| Action | Result |
|---|---|
| Short press | GRIP_CMD (J3-3) and ARM_IN_POS (J3-5) toggle together between 0 V and 3.3 V. ARM_IN_POS is also on J5 pin 4. |

| DS2 | Meaning |
|---|---|
| On | At least one input reads 1: SAFE_OK (J3-1), RUN_REQ (J3-2), OBJ_HELD (J3-4), or SPEED_SET (J3-6) above 1.65 V, read by the ADC |
| Short flash once a second | All inputs read 0 |

Ribbon check demo:

1. **Pin 8 is ground.** Measure continuity from J3 pin 8 to TP3 (GND).
2. **Write.** Press the button and measure J3 pin 3 and pin 5 against pin 8. They read 3.3 V, then 0 V on the next press.
3. **Read.** Touch a jumper wire from 3.3 V (J4 pin 1) to J3 pin 1, 2, 4 or 6, one at a time. DS2 turns on.
    * Pins 1, 2 and 4 have pull-downs, so DS2 turns off again when the wire is removed.
    * For pin 6, touch it to pin 8 (GND) afterwards to bring it back to 0.
4. **Read and write together.** Put a jumper from J3 pin 3 to pin 4. DS2 now follows every button press.

## APP mode

The cycle follows the team Software Proposal and Message Structure pages.

1. **IDLE:** wait for SAFE_OK = 1 and a new Start (RUN_REQ goes 0 → 1).
2. **MOVE_TO_PICK:** forward PWM for the move time, then settle. ARM_IN_POS = 1, GRIP_CMD = 1.
3. **WAIT_GRIP:** wait up to 3 s for OBJ_HELD = 1.
    * On timeout: GRIP_CMD = 0, wait 1 s, and retry once.
    * A second timeout goes to FAULT.
4. **MOVE_TO_PLACE:** ARM_IN_POS = 0, then reverse PWM for the same time as the pick move. Then ARM_IN_POS = 1, GRIP_CMD = 0.
5. **RELEASE:** wait for OBJ_HELD = 0, then DONE. The cycle repeats while RUN_REQ = 1; otherwise the board returns to IDLE.

**Stop, pause and fault:**

* **SAFE_OK = 0, at any time:** STOP. Both PWM outputs go to 0 % within 1 ms. GRIP_CMD is left as it was, so the gripper keeps holding.
* **Restart after STOP or FAULT:** needs SAFE_OK = 1 and a new Start press. An interrupted move finishes the time it had left.
* **RUN_REQ = 0 during a move:** the move finishes, and the arm waits before the next one.

**Speed:** the duty is read from SPEED_SET at the start of each cycle: 0 V → 35 %, 3.3 V → 100 %. The move time is scaled by 60 % / duty, so the arm turns about the same angle at any speed. Tune `MOVE_MS_AT_REF` on the bench.

| DS2 | State |
|---|---|
| Slow blink | IDLE or PAUSED |
| On | Moving |
| 4 Hz blink | Waiting for the gripper |
| Short flash once a second | STOP |
| 10 Hz blink | FAULT |

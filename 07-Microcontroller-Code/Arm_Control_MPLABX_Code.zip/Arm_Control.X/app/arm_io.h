/*
 * arm_io.h
 * Board-level helpers for the Arm Motion Control board:
 * 1 ms time base, motor (FAN8100N), team link, SPEED_SET, button, LED.
 */
#ifndef ARM_IO_H
#define ARM_IO_H

#include <stdint.h>
#include <stdbool.h>

/* ---------------- 1 ms time base (TMR0) ---------------- */
void     Tick_Init(void);
void     Tick_Update(void);          /* call as often as possible    */
uint32_t Tick_Ms(void);              /* ms since power-up            */

/* ---------------- Motor (PWM1 -> FAN8100N) ---------------- */
typedef enum
{
    MOTOR_STOP = 0,
    MOTOR_FWD,                       /* PWM on RC4 (FORWARDA), RC5 = 0 */
    MOTOR_REV                        /* PWM on RC5 (REVERSEA), RC4 = 0 */
} motor_dir_t;

void        Motor_Init(void);
void        Motor_Run(motor_dir_t dir, uint8_t duty_pct); /* request    */
void        Motor_Stop(void);        /* both outputs 0 %, immediately */
void        Motor_Task1ms(void);     /* handles the reversal gap      */
motor_dir_t Motor_Dir(void);         /* what is on the pins now       */
uint8_t     Motor_Duty(void);

/* ---------------- Team link (J3) ---------------- */
void Link_Init(void);
void Link_Task1ms(void);             /* debounces the three inputs    */
bool Link_SafeOk(void);              /* pin 1                         */
bool Link_RunReq(void);              /* pin 2                         */
bool Link_ObjHeld(void);             /* pin 4                         */
void Link_SetGripCmd(bool on);       /* pin 3                         */
void Link_SetArmInPos(bool on);      /* pin 5                         */
bool Link_GripCmd(void);
bool Link_ArmInPos(void);
uint8_t Link_RawInputs(void);        /* bit0 SAFE_OK, bit1 RUN_REQ,
                                        bit2 OBJ_HELD, not debounced  */

/* ---------------- SPEED_SET (pin 6, RA1 / ANA1) ---------------- */
void     Speed_Init(void);
void     Speed_Task1ms(void);
uint16_t Speed_Raw(void);            /* averaged 0..4095              */
uint16_t Speed_ReadNow(void);        /* one conversion, no averaging  */
uint16_t Speed_Millivolts(void);
uint8_t  Speed_DutyPct(void);        /* DUTY_MIN..DUTY_MAX            */

/* ---------------- Debug button (RE1, active low) ---------------- */
typedef enum
{
    BTN_NONE = 0,
    BTN_SHORT,                       /* released before BTN_LONG_MS   */
    BTN_LONG                         /* held for BTN_LONG_MS          */
} btn_event_t;

void        Button_Task1ms(void);
btn_event_t Button_GetEvent(void);   /* returns each event once       */

/* ---------------- Debug LED (RE0) ---------------- */
typedef enum
{
    LED_OFF = 0,
    LED_ON,
    LED_SLOW,                        /* 1 Hz                          */
    LED_MEDIUM,                      /* 4 Hz                          */
    LED_FAST,                        /* 10 Hz                         */
    LED_BLIP                         /* short flash once a second     */
} led_pattern_t;

void Led_Set(led_pattern_t pattern);
void Led_Task1ms(void);

#endif /* ARM_IO_H */

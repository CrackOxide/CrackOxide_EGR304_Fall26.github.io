/*
 * arm_config.h
 * Arm Motion Control board (YR) - Team 107, EGR304 Fall 2026
 *
 * All the numbers you may want to tune on the bench are here.
 * Change a value, rebuild, and program the Nano again.
 */
#ifndef ARM_CONFIG_H
#define ARM_CONFIG_H

/* ------------------------------------------------------------------ */
/* Start-up mode                                                       */
/* ------------------------------------------------------------------ */
/* MODE_TEST : stand-alone hardware verification (button flips the
 *             motor direction; team link read/write test on DS2).
 * MODE_APP  : team pick-and-place cycle driven by the 8-pin team link.
 * Holding BTN_DBG while the Nano powers up starts the other mode.     */
#define MODE_TEST               0
#define MODE_APP                1
#define BOOT_MODE               MODE_TEST

/* In test mode the board is usually alone on the bench, so SAFE_OK
 * (pin 1) reads 0 through its pull-down. Set this to 1 to make test
 * mode obey SAFE_OK as well, once the User board is connected.        */
#define TEST_OBEYS_SAFE_OK      0

/* ------------------------------------------------------------------ */
/* Motor PWM (PWM1_16BIT, 1 kHz, PR = 63999 from MCC)                  */
/* ------------------------------------------------------------------ */
#define PWM_PERIOD_COUNTS       64000UL  /* PR + 1                     */
#define MOTOR_REVERSE_GAP_MS    250      /* both outputs off before a
                                            direction change            */
#define TEST_DUTY_PCT           60       /* fixed duty in test mode     */

/* SPEED_SET (pin 6, 0-3.3 V) is mapped to DUTY_MIN..DUTY_MAX.
 * 0 V means "slowest", not "stopped" (Message Structure page).        */
#define DUTY_MIN_PCT            35
#define DUTY_MAX_PCT            100

/* ------------------------------------------------------------------ */
/* Timed moves (no joint position sensor on the first prototype)       */
/* ------------------------------------------------------------------ */
/* Move time at the reference duty. At other duties the time is scaled
 * by DUTY_REF / duty, so the arm turns about the same angle at any
 * speed. Tune MOVE_MS_AT_REF on the bench.                            */
#define MOVE_MS_AT_REF          1500UL
#define DUTY_REF_PCT            60UL
#define MOVE_MS_MAX             6000UL
#define SETTLE_MS               300      /* wait after a move before
                                            ARM_IN_POS = 1              */

/* ------------------------------------------------------------------ */
/* Gripper handshake                                                   */
/* ------------------------------------------------------------------ */
#define GRIP_TIMEOUT_MS         3000     /* wait for OBJ_HELD = 1       */
#define GRIP_RETRIES            1        /* retry once, then FAULT      */
#define GRIP_REOPEN_MS          1000     /* GRIP_CMD = 0 before a retry */
#define RELEASE_TIMEOUT_MS      3000     /* wait for OBJ_HELD = 0       */

/* ------------------------------------------------------------------ */
/* Inputs                                                              */
/* ------------------------------------------------------------------ */
#define LINK_DEBOUNCE_MS        10       /* a link input must be stable
                                            this long to change.
                                            SAFE_OK = 0 acts at once.  */
#define BTN_DEBOUNCE_MS         20
#define BTN_LONG_MS             1500     /* long press = stop and switch
                                            MOTOR <-> LINK test        */
#define SPEED_SAMPLE_MS         10       /* ADC sample period           */
#define SPEED_AVG_SAMPLES       8        /* moving average length       */

#endif /* ARM_CONFIG_H */

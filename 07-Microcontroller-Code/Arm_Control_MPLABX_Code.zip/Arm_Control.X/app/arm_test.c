/*
 * arm_test.c
 * Hardware verification mode (MODE_TEST) for the Arm Motion Control
 * board. Only the debug button BTN_DBG (SW1, RE1) and the debug LED
 * DS2 (RE0) are used, plus a multimeter on the headers.
 *
 * There are two tests. Hold BTN_DBG for 1.5 s to switch between them
 * (this also stops the motor).
 *
 * MOTOR test (at power-up)
 *   Short press : STOP -> FWD, then each press flips FWD <-> REV
 *                 (FWD = PWM on RC4 / RC5 = 0, REV = PWM on RC5 / RC4 = 0,
 *                  both off for 250 ms between directions)
 *   DS2         : slow blink = stopped, on = FWD, 4 Hz blink = REV
 *
 * LINK test (team link J3, 8-pin ribbon check)
 *   Short press : toggles both outputs, GRIP_CMD (J3-3) and
 *                 ARM_IN_POS (J3-5), together between 0 V and 3.3 V
 *   DS2         : on while any input reads 1:
 *                   SAFE_OK (J3-1), RUN_REQ (J3-2), OBJ_HELD (J3-4),
 *                   or SPEED_SET (J3-6) above 1.65 V (read by the ADC)
 *                 short flash once a second when all inputs read 0
 */
#include "../mcc_generated_files/system/system.h"
#include "arm_config.h"
#include "arm_io.h"
#include "arm_test.h"

#define SPEED_HIGH_RAW  2048u            /* 1.65 V of 3.3 V             */

typedef enum
{
    TEST_MOTOR = 0,
    TEST_LINK
} test_t;

static test_t      test;
static motor_dir_t test_dir;             /* direction asked for         */
static bool        outputs_on;

static void set_dir(motor_dir_t dir)
{
#if TEST_OBEYS_SAFE_OK
    if (!Link_SafeOk())
    {
        dir = MOTOR_STOP;
    }
#endif
    test_dir = dir;
    if (dir == MOTOR_STOP)
    {
        Motor_Stop();
        Led_Set(LED_SLOW);
    }
    else
    {
        Motor_Run(dir, TEST_DUTY_PCT);
        Led_Set((dir == MOTOR_FWD) ? LED_ON : LED_MEDIUM);
    }
}

static void start_motor_test(void)
{
    test = TEST_MOTOR;
    outputs_on = false;
    Link_SetGripCmd(false);
    Link_SetArmInPos(false);
    set_dir(MOTOR_STOP);
}

static void start_link_test(void)
{
    test = TEST_LINK;
    Motor_Stop();
    test_dir = MOTOR_STOP;
    outputs_on = false;
    Link_SetGripCmd(false);
    Link_SetArmInPos(false);
    Led_Set(LED_BLIP);
}

void Test_Enter(void)
{
    start_motor_test();
}

void Test_Task1ms(void)
{
    btn_event_t ev = Button_GetEvent();

    /* Long press: stop and switch between the two tests. */
    if (ev == BTN_LONG)
    {
        if (test == TEST_MOTOR)
        {
            start_link_test();
        }
        else
        {
            start_motor_test();
        }
        return;
    }

    if (test == TEST_MOTOR)
    {
#if TEST_OBEYS_SAFE_OK
        if (!Link_SafeOk() && (test_dir != MOTOR_STOP))
        {
            set_dir(MOTOR_STOP);
        }
#endif
        if (ev == BTN_SHORT)
        {
            set_dir((test_dir == MOTOR_FWD) ? MOTOR_REV : MOTOR_FWD);
        }
    }
    else
    {
        bool any_high;

        if (ev == BTN_SHORT)
        {
            outputs_on = !outputs_on;
            Link_SetGripCmd(outputs_on);
            Link_SetArmInPos(outputs_on);
        }

        any_high = Link_SafeOk() || Link_RunReq() || Link_ObjHeld() ||
                   (Speed_Raw() >= SPEED_HIGH_RAW);
        Led_Set(any_high ? LED_ON : LED_BLIP);
    }
}

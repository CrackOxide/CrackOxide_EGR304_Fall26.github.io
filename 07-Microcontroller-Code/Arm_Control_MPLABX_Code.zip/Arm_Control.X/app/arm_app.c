/*
 * arm_app.c
 * Team pick-and-place state machine (MODE_APP).
 *
 * Follows the Team 107 Software Proposal and Message Structure pages:
 *
 *   IDLE --(SAFE_OK & new RUN_REQ)--> MOVE_TO_PICK (forward, timed)
 *        --> ARM_IN_POS = 1, GRIP_CMD = 1 --> WAIT_GRIP
 *        --(OBJ_HELD = 1)--> ARM_IN_POS = 0 --> MOVE_TO_PLACE (reverse)
 *        --> ARM_IN_POS = 1, GRIP_CMD = 0 --> RELEASE
 *        --(OBJ_HELD = 0)--> DONE --> repeat while RUN_REQ = 1
 *
 *   Any state --(SAFE_OK = 0)--> STOP: both PWM outputs 0 % at once.
 *   STOP --(SAFE_OK = 1, RUN_REQ goes 0 then 1)--> resume where it was.
 *
 *   No OBJ_HELD within GRIP_TIMEOUT_MS: GRIP_CMD = 0, wait, retry once,
 *   then FAULT. FAULT waits for a new Start press (RUN_REQ 0 -> 1).
 *
 *   RUN_REQ = 0 during a move: the move finishes ("pause after the
 *   current move"), and the arm waits before starting the next one.
 */
#include "../mcc_generated_files/system/system.h"
#include "arm_config.h"
#include "arm_io.h"
#include "arm_app.h"

static app_state_t state = APP_IDLE;
static app_state_t saved_state;      /* state to resume after STOP    */
static app_state_t fault_state;      /* state that failed             */
static uint32_t    move_left_ms;     /* motor-on time still to run    */
static uint16_t    timer_ms;         /* settle / timeout counter      */
static uint8_t     move_duty;        /* duty locked for this cycle    */
static uint32_t    move_ms;          /* move time locked for this cycle*/
static uint8_t     retries;
static bool        start_armed;      /* RUN_REQ seen low since stop   */
static uint16_t    cycles;

app_state_t App_State(void)
{
    return state;
}

uint16_t App_Cycles(void)
{
    return cycles;
}

static void go(app_state_t next)
{
    state = next;

    switch (next)
    {
        case APP_IDLE:
        case APP_PAUSED:        Led_Set(LED_SLOW);   break;
        case APP_MOVE_TO_PICK:
        case APP_MOVE_TO_PLACE: Led_Set(LED_ON);     break;
        case APP_STOP:          Led_Set(LED_BLIP);   break;
        case APP_FAULT:         Led_Set(LED_FAST);   break;
        default:                Led_Set(LED_MEDIUM); break;
    }
}

/* Lock the duty and the move time at the start of a cycle, so the
 * place move (reverse) is exactly as long as the pick move (forward)
 * and the arm comes back to where it started.                        */
static void lock_speed(void)
{
    move_duty = Speed_DutyPct();
    move_ms = (MOVE_MS_AT_REF * DUTY_REF_PCT) / move_duty;
    if (move_ms > MOVE_MS_MAX)
    {
        move_ms = MOVE_MS_MAX;
    }
}

static void start_move(app_state_t move_state)
{
    motor_dir_t dir = (move_state == APP_MOVE_TO_PICK) ? MOTOR_FWD
                                                       : MOTOR_REV;
    Link_SetArmInPos(false);             /* arm is moving               */
    move_left_ms = move_ms;
    timer_ms = 0;
    Motor_Run(dir, move_duty);
    go(move_state);
}

static void start_grip_wait(void)
{
    Link_SetGripCmd(true);
    timer_ms = GRIP_TIMEOUT_MS;
    go(APP_WAIT_GRIP);
}

static void enter_stop(void)
{
    Motor_Stop();                        /* both PWM 0 % right now      */
    saved_state = state;
    start_armed = false;
    go(APP_STOP);
}

static void enter_fault(app_state_t failed)
{
    Motor_Stop();
    fault_state = failed;
    start_armed = false;
    go(APP_FAULT);
}

/* Continue a state that was interrupted by STOP. GRIP_CMD and
 * ARM_IN_POS were left as they were, so the gripper keeps holding.   */
static void resume(app_state_t s)
{
    switch (s)
    {
        case APP_MOVE_TO_PICK:
        case APP_MOVE_TO_PLACE:
            if (move_left_ms > 0u)
            {
                Motor_Run((s == APP_MOVE_TO_PICK) ? MOTOR_FWD : MOTOR_REV,
                          move_duty);
            }
            go(s);
            break;
        case APP_WAIT_GRIP:
            timer_ms = GRIP_TIMEOUT_MS;
            go(s);
            break;
        case APP_REOPEN:
            timer_ms = GRIP_REOPEN_MS;
            go(s);
            break;
        case APP_RELEASE:
            timer_ms = RELEASE_TIMEOUT_MS;
            go(s);
            break;
        case APP_DONE:
            timer_ms = SETTLE_MS;
            go(s);
            break;
        default:                         /* IDLE, PAUSED, FAULT         */
            go(s);
            break;
    }
}

/* Shared by both moves. Returns true once the move and the settle
 * time are over. Time only counts while the motor is really on, so
 * the reversal gap in Motor_Run() does not shorten the move.         */
static bool move_task(void)
{
    if (move_left_ms > 0u)
    {
        if (Motor_Dir() != MOTOR_STOP)
        {
            if (--move_left_ms == 0u)
            {
                Motor_Stop();
                timer_ms = SETTLE_MS;
            }
        }
        return false;
    }
    if (timer_ms > 0u)
    {
        timer_ms--;
        return false;
    }
    return true;
}

void App_Enter(void)
{
    Motor_Stop();
    Link_SetGripCmd(false);
    Link_SetArmInPos(false);
    start_armed = false;                 /* need a fresh Start press    */
    retries = 0;
    move_left_ms = 0;
    timer_ms = 0;
    state = APP_IDLE;
    Led_Set(LED_SLOW);
}

void App_Task1ms(void)
{
    bool safe = Link_SafeOk();
    bool run  = Link_RunReq();
    bool held = Link_ObjHeld();

    /* ---- 1. Safety check first, every loop ---- */
    if (!safe)
    {
        if (state != APP_STOP)
        {
            enter_stop();
        }
        else
        {
            Motor_Stop();                /* keep it off                 */
        }
    }

    /* A restart must be a new Start press (RUN_REQ 0 -> 1). */
    if (!run)
    {
        start_armed = true;
    }

    /* ---- 2. State machine ---- */
    switch (state)
    {
        case APP_IDLE:
            if (safe && run && start_armed)
            {
                lock_speed();
                start_move(APP_MOVE_TO_PICK);
            }
            break;

        case APP_MOVE_TO_PICK:
            if (move_task())
            {
                Link_SetArmInPos(true);  /* at pick                     */
                retries = 0;
                start_grip_wait();
            }
            break;

        case APP_WAIT_GRIP:
            if (held)
            {
                if (run)
                {
                    start_move(APP_MOVE_TO_PLACE);   /* GRIP_CMD stays 1 */
                }
                else
                {
                    go(APP_PAUSED);
                }
            }
            else if (timer_ms > 0u)
            {
                timer_ms--;
            }
            else
            {
                Link_SetGripCmd(false);  /* no grip: open the gripper   */
                if (retries < GRIP_RETRIES)
                {
                    retries++;
                    timer_ms = GRIP_REOPEN_MS;
                    go(APP_REOPEN);
                }
                else
                {
                    enter_fault(APP_WAIT_GRIP);
                }
            }
            break;

        case APP_REOPEN:
            if (timer_ms > 0u)
            {
                timer_ms--;
            }
            else
            {
                start_grip_wait();       /* retry                       */
            }
            break;

        case APP_PAUSED:
            if (safe && run)
            {
                start_move(APP_MOVE_TO_PLACE);
            }
            break;

        case APP_MOVE_TO_PLACE:
            if (move_task())
            {
                Link_SetArmInPos(true);  /* at place                    */
                Link_SetGripCmd(false);  /* open                        */
                timer_ms = RELEASE_TIMEOUT_MS;
                go(APP_RELEASE);
            }
            break;

        case APP_RELEASE:
            if (!held)
            {
                cycles++;
                timer_ms = SETTLE_MS;    /* let the User board count it */
                go(APP_DONE);
            }
            else if (timer_ms > 0u)
            {
                timer_ms--;
            }
            else
            {
                enter_fault(APP_RELEASE);
            }
            break;

        case APP_DONE:
            if (timer_ms > 0u)
            {
                timer_ms--;
            }
            else if (run)
            {
                lock_speed();            /* next cycle                  */
                start_move(APP_MOVE_TO_PICK);
            }
            else
            {
                Link_SetArmInPos(false);
                go(APP_IDLE);            /* paused between cycles       */
            }
            break;

        case APP_STOP:
            if (safe && run && start_armed)
            {
                resume(saved_state);
            }
            break;

        case APP_FAULT:
            Motor_Stop();
            if (safe && run && start_armed)
            {
                if (fault_state == APP_RELEASE)
                {
                    Link_SetGripCmd(false);
                    timer_ms = RELEASE_TIMEOUT_MS;
                    go(APP_RELEASE);
                }
                else
                {
                    retries = 0;
                    start_grip_wait();
                }
            }
            break;

        default:
            enter_stop();
            break;
    }
}

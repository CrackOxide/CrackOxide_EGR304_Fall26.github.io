/*
 * adc.c - ADCC driver for the Arm Motion Control board.
 *
 * NOTE: the project zip had adc.h / adc_types.h but no adc.c (the last
 * MCC generation reported a failure), so the project could not link.
 * This file is a hand-written stand-in that implements the parts of the
 * MCC Melody ADCC API this project uses, with the same settings as the
 * MCC configuration in Arm_Control.mc3:
 *   clock ADCRC, result right-justified, VREF+ = VDD, VREF- = VSS,
 *   channel ANA1 (RA1, SPEED_SET), acquisition 10 TAD, basic mode,
 *   no interrupts.
 * If you open MCC and press Generate, MCC writes its own adc.c over this
 * one. That is fine: main.c and app/ only use the standard API.
 */
#include <xc.h>
#include <stddef.h>
#include "../adc.h"

static void (*ADC_ConversionDoneCallback)(void);
static void (*ADC_ThresholdCallback)(void);

void ADC_Initialize(void)
{
    ADCON0 = 0x00;          /* off while configuring                  */
    ADCON1 = 0x00;          /* no precharge polarity / double sample  */
    ADCON2 = 0x00;          /* basic mode, no accumulation            */
    ADCON3 = 0x00;          /* no threshold interrupt                 */
    ADSTAT = 0x00;
    ADREF  = 0x00;          /* VREF+ = VDD, VREF- = VSS               */
    ADACT  = 0x00;          /* no auto-conversion trigger             */
    ADCLK  = 0x00;          /* only used with FOSC clock              */
    ADPRE  = 0x00;          /* no precharge                           */
    ADACQ  = 10;            /* 10 TAD acquisition                     */
    ADCAP  = 0x00;
    ADRPT  = 0x00;
    ADPCH  = (uint8_t)ADC_CHANNEL_ANA1;

    PIR1bits.ADIF  = 0;
    PIE1bits.ADIE  = 0;
    PIR2bits.ADTIF = 0;
    PIE2bits.ADTIE = 0;

    ADC_ConversionDoneCallback = NULL;
    ADC_ThresholdCallback = NULL;

    /* ON = 1, CONT = 0, CS = ADCRC, FM = right-justified, GO = 0 */
    ADCON0 = 0x94;
}

void ADC_Deinitialize(void)
{
    ADCON0 = 0x00;
}

void ADC_Enable(void)
{
    ADCON0bits.ON = 1;
}

void ADC_Disable(void)
{
    ADCON0bits.ON = 0;
}

void ADC_ChannelSelect(adc_channel_t channel)
{
    ADPCH = (uint8_t)channel;
}

void ADC_ConversionStart(void)
{
    ADCON0bits.GO = 1;
}

bool ADC_IsConversionDone(void)
{
    return (ADCON0bits.GO == 0);
}

void ADC_ConversionStop(void)
{
    ADCON0bits.GO = 0;
}

adc_result_t ADC_ConversionResultGet(void)
{
    return (adc_result_t)(((uint16_t)ADRESH << 8) | ADRESL);
}

adc_result_t ADC_ChannelSelectAndConvert(adc_channel_t channel)
{
    ADPCH = (uint8_t)channel;
    ADCON0bits.ON = 1;
    ADCON0bits.CONT = 0;
    ADCON0bits.GO = 1;
    while (ADCON0bits.GO == 1)
    {
    }
    return ADC_ConversionResultGet();
}

void ADC_ConversionDoneCallbackRegister(void (*callback)(void))
{
    ADC_ConversionDoneCallback = callback;
}

void ADC_ThresholdCallbackRegister(void (*callback)(void))
{
    ADC_ThresholdCallback = callback;
}

/* Called by interrupt.c. The interrupts are not enabled in this
 * project, but the interrupt manager still references these.        */
void ADC_ISR(void)
{
    PIR1bits.ADIF = 0;
    if (ADC_ConversionDoneCallback != NULL)
    {
        ADC_ConversionDoneCallback();
    }
}

void ADC_ThresholdISR(void)
{
    PIR2bits.ADTIF = 0;
    if (ADC_ThresholdCallback != NULL)
    {
        ADC_ThresholdCallback();
    }
}

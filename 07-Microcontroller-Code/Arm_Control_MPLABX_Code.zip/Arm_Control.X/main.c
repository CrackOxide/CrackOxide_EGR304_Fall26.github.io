/*
 * main.c
 * Arm Motion Control board (YR) - Team 107, EGR304 Fall 2026
 * Yixiang Ren
 *
 * MCU   : PIC18F57Q43 Curiosity Nano, HFINTOSC 64 MHz
 * Tools : MPLAB X, XC8, MCC Melody (clock, pins, ADCC, PWM1_16BIT)
 *
 * The program runs a 1 ms loop. Every millisecond it
 *   1. reads and debounces the team link inputs and the debug button,
 *   2. samples SPEED_SET,
 *   3. runs the active mode:
 *        TEST mode - stand-alone hardware verification (arm_test.c)
 *        APP  mode - team pick-and-place state machine  (arm_app.c)
 *   4. updates the motor reversal gap and the debug LED DS2.
 *
 * Choosing the mode:
 *   BOOT_MODE in app/arm_config.h sets the normal start-up mode.
 *   Holding BTN_DBG while the Nano powers up starts the other mode.
 *
 * No UART is used. Tunable numbers are in app/arm_config.h.
 */
#include "mcc_generated_files/system/system.h"
#include "app/arm_config.h"
#include "app/arm_io.h"
#include "app/arm_app.h"
#include "app/arm_test.h"

static uint8_t mode;

int main(void)
{
    uint32_t last_ms;

    SYSTEM_Initialize();                 /* MCC: PWM starts at 0 %      */

    Tick_Init();
    Motor_Init();                        /* both outputs 0 %            */
    Link_Init();                         /* GRIP_CMD = ARM_IN_POS = 0   */
    Speed_Init();
    Led_Set(LED_OFF);

    /* Button held at power-up (active low) -> the other mode. */
    mode = BOOT_MODE;
    if (BTN_DBG_GetValue() == 0)
    {
        mode = (BOOT_MODE == MODE_APP) ? MODE_TEST : MODE_APP;
        while (BTN_DBG_GetValue() == 0)  /* wait for release, so the  */
        {                                /* press is not used as a    */
        }                                /* command                   */
    }

    if (mode == MODE_APP)
    {
        App_Enter();
    }
    else
    {
        Test_Enter();
    }

    last_ms = Tick_Ms();
    while (1)
    {
        Tick_Update();
        while (last_ms != Tick_Ms())     /* once per elapsed ms         */
        {
            last_ms++;
            Link_Task1ms();
            Button_Task1ms();
            Speed_Task1ms();

            if (mode == MODE_APP)
            {
                App_Task1ms();           /* safety check is inside      */
            }
            else
            {
                Test_Task1ms();
            }

            Motor_Task1ms();
            Led_Task1ms();
        }
    }
}

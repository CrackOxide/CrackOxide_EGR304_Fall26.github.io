/**
 * Generated Pins header File
 * 
 * @file pins.h
 * 
 * @defgroup  pinsdriver Pins Driver
 * 
 * @brief This is generated driver header for pins. 
 *        This header file provides APIs for all pins selected in the GUI.
 *
 * @version Driver Version  3.1.1
*/

/*
? [2026] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

#ifndef PINS_H
#define PINS_H

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set RA1 aliases
#define SPEED_SET_TRIS                 TRISAbits.TRISA1
#define SPEED_SET_LAT                  LATAbits.LATA1
#define SPEED_SET_PORT                 PORTAbits.RA1
#define SPEED_SET_WPU                  WPUAbits.WPUA1
#define SPEED_SET_OD                   ODCONAbits.ODCA1
#define SPEED_SET_ANS                  ANSELAbits.ANSELA1
#define SPEED_SET_SetHigh()            do { LATAbits.LATA1 = 1; } while(0)
#define SPEED_SET_SetLow()             do { LATAbits.LATA1 = 0; } while(0)
#define SPEED_SET_Toggle()             do { LATAbits.LATA1 = ~LATAbits.LATA1; } while(0)
#define SPEED_SET_GetValue()           PORTAbits.RA1
#define SPEED_SET_SetDigitalInput()    do { TRISAbits.TRISA1 = 1; } while(0)
#define SPEED_SET_SetDigitalOutput()   do { TRISAbits.TRISA1 = 0; } while(0)
#define SPEED_SET_SetPullup()          do { WPUAbits.WPUA1 = 1; } while(0)
#define SPEED_SET_ResetPullup()        do { WPUAbits.WPUA1 = 0; } while(0)
#define SPEED_SET_SetPushPull()        do { ODCONAbits.ODCA1 = 0; } while(0)
#define SPEED_SET_SetOpenDrain()       do { ODCONAbits.ODCA1 = 1; } while(0)
#define SPEED_SET_SetAnalogMode()      do { ANSELAbits.ANSELA1 = 1; } while(0)
#define SPEED_SET_SetDigitalMode()     do { ANSELAbits.ANSELA1 = 0; } while(0)

// get/set RC4 aliases
#define MOT_FWD_TRIS                 TRISCbits.TRISC4
#define MOT_FWD_LAT                  LATCbits.LATC4
#define MOT_FWD_PORT                 PORTCbits.RC4
#define MOT_FWD_WPU                  WPUCbits.WPUC4
#define MOT_FWD_OD                   ODCONCbits.ODCC4
#define MOT_FWD_ANS                  ANSELCbits.ANSELC4
#define MOT_FWD_SetHigh()            do { LATCbits.LATC4 = 1; } while(0)
#define MOT_FWD_SetLow()             do { LATCbits.LATC4 = 0; } while(0)
#define MOT_FWD_Toggle()             do { LATCbits.LATC4 = ~LATCbits.LATC4; } while(0)
#define MOT_FWD_GetValue()           PORTCbits.RC4
#define MOT_FWD_SetDigitalInput()    do { TRISCbits.TRISC4 = 1; } while(0)
#define MOT_FWD_SetDigitalOutput()   do { TRISCbits.TRISC4 = 0; } while(0)
#define MOT_FWD_SetPullup()          do { WPUCbits.WPUC4 = 1; } while(0)
#define MOT_FWD_ResetPullup()        do { WPUCbits.WPUC4 = 0; } while(0)
#define MOT_FWD_SetPushPull()        do { ODCONCbits.ODCC4 = 0; } while(0)
#define MOT_FWD_SetOpenDrain()       do { ODCONCbits.ODCC4 = 1; } while(0)
#define MOT_FWD_SetAnalogMode()      do { ANSELCbits.ANSELC4 = 1; } while(0)
#define MOT_FWD_SetDigitalMode()     do { ANSELCbits.ANSELC4 = 0; } while(0)

// get/set RC5 aliases
#define MOT_REV_TRIS                 TRISCbits.TRISC5
#define MOT_REV_LAT                  LATCbits.LATC5
#define MOT_REV_PORT                 PORTCbits.RC5
#define MOT_REV_WPU                  WPUCbits.WPUC5
#define MOT_REV_OD                   ODCONCbits.ODCC5
#define MOT_REV_ANS                  ANSELCbits.ANSELC5
#define MOT_REV_SetHigh()            do { LATCbits.LATC5 = 1; } while(0)
#define MOT_REV_SetLow()             do { LATCbits.LATC5 = 0; } while(0)
#define MOT_REV_Toggle()             do { LATCbits.LATC5 = ~LATCbits.LATC5; } while(0)
#define MOT_REV_GetValue()           PORTCbits.RC5
#define MOT_REV_SetDigitalInput()    do { TRISCbits.TRISC5 = 1; } while(0)
#define MOT_REV_SetDigitalOutput()   do { TRISCbits.TRISC5 = 0; } while(0)
#define MOT_REV_SetPullup()          do { WPUCbits.WPUC5 = 1; } while(0)
#define MOT_REV_ResetPullup()        do { WPUCbits.WPUC5 = 0; } while(0)
#define MOT_REV_SetPushPull()        do { ODCONCbits.ODCC5 = 0; } while(0)
#define MOT_REV_SetOpenDrain()       do { ODCONCbits.ODCC5 = 1; } while(0)
#define MOT_REV_SetAnalogMode()      do { ANSELCbits.ANSELC5 = 1; } while(0)
#define MOT_REV_SetDigitalMode()     do { ANSELCbits.ANSELC5 = 0; } while(0)

// get/set RD0 aliases
#define SAFE_OK_TRIS                 TRISDbits.TRISD0
#define SAFE_OK_LAT                  LATDbits.LATD0
#define SAFE_OK_PORT                 PORTDbits.RD0
#define SAFE_OK_WPU                  WPUDbits.WPUD0
#define SAFE_OK_OD                   ODCONDbits.ODCD0
#define SAFE_OK_ANS                  ANSELDbits.ANSELD0
#define SAFE_OK_SetHigh()            do { LATDbits.LATD0 = 1; } while(0)
#define SAFE_OK_SetLow()             do { LATDbits.LATD0 = 0; } while(0)
#define SAFE_OK_Toggle()             do { LATDbits.LATD0 = ~LATDbits.LATD0; } while(0)
#define SAFE_OK_GetValue()           PORTDbits.RD0
#define SAFE_OK_SetDigitalInput()    do { TRISDbits.TRISD0 = 1; } while(0)
#define SAFE_OK_SetDigitalOutput()   do { TRISDbits.TRISD0 = 0; } while(0)
#define SAFE_OK_SetPullup()          do { WPUDbits.WPUD0 = 1; } while(0)
#define SAFE_OK_ResetPullup()        do { WPUDbits.WPUD0 = 0; } while(0)
#define SAFE_OK_SetPushPull()        do { ODCONDbits.ODCD0 = 0; } while(0)
#define SAFE_OK_SetOpenDrain()       do { ODCONDbits.ODCD0 = 1; } while(0)
#define SAFE_OK_SetAnalogMode()      do { ANSELDbits.ANSELD0 = 1; } while(0)
#define SAFE_OK_SetDigitalMode()     do { ANSELDbits.ANSELD0 = 0; } while(0)

// get/set RD1 aliases
#define RUN_REQ_TRIS                 TRISDbits.TRISD1
#define RUN_REQ_LAT                  LATDbits.LATD1
#define RUN_REQ_PORT                 PORTDbits.RD1
#define RUN_REQ_WPU                  WPUDbits.WPUD1
#define RUN_REQ_OD                   ODCONDbits.ODCD1
#define RUN_REQ_ANS                  ANSELDbits.ANSELD1
#define RUN_REQ_SetHigh()            do { LATDbits.LATD1 = 1; } while(0)
#define RUN_REQ_SetLow()             do { LATDbits.LATD1 = 0; } while(0)
#define RUN_REQ_Toggle()             do { LATDbits.LATD1 = ~LATDbits.LATD1; } while(0)
#define RUN_REQ_GetValue()           PORTDbits.RD1
#define RUN_REQ_SetDigitalInput()    do { TRISDbits.TRISD1 = 1; } while(0)
#define RUN_REQ_SetDigitalOutput()   do { TRISDbits.TRISD1 = 0; } while(0)
#define RUN_REQ_SetPullup()          do { WPUDbits.WPUD1 = 1; } while(0)
#define RUN_REQ_ResetPullup()        do { WPUDbits.WPUD1 = 0; } while(0)
#define RUN_REQ_SetPushPull()        do { ODCONDbits.ODCD1 = 0; } while(0)
#define RUN_REQ_SetOpenDrain()       do { ODCONDbits.ODCD1 = 1; } while(0)
#define RUN_REQ_SetAnalogMode()      do { ANSELDbits.ANSELD1 = 1; } while(0)
#define RUN_REQ_SetDigitalMode()     do { ANSELDbits.ANSELD1 = 0; } while(0)

// get/set RD2 aliases
#define GRIP_CMD_TRIS                 TRISDbits.TRISD2
#define GRIP_CMD_LAT                  LATDbits.LATD2
#define GRIP_CMD_PORT                 PORTDbits.RD2
#define GRIP_CMD_WPU                  WPUDbits.WPUD2
#define GRIP_CMD_OD                   ODCONDbits.ODCD2
#define GRIP_CMD_ANS                  ANSELDbits.ANSELD2
#define GRIP_CMD_SetHigh()            do { LATDbits.LATD2 = 1; } while(0)
#define GRIP_CMD_SetLow()             do { LATDbits.LATD2 = 0; } while(0)
#define GRIP_CMD_Toggle()             do { LATDbits.LATD2 = ~LATDbits.LATD2; } while(0)
#define GRIP_CMD_GetValue()           PORTDbits.RD2
#define GRIP_CMD_SetDigitalInput()    do { TRISDbits.TRISD2 = 1; } while(0)
#define GRIP_CMD_SetDigitalOutput()   do { TRISDbits.TRISD2 = 0; } while(0)
#define GRIP_CMD_SetPullup()          do { WPUDbits.WPUD2 = 1; } while(0)
#define GRIP_CMD_ResetPullup()        do { WPUDbits.WPUD2 = 0; } while(0)
#define GRIP_CMD_SetPushPull()        do { ODCONDbits.ODCD2 = 0; } while(0)
#define GRIP_CMD_SetOpenDrain()       do { ODCONDbits.ODCD2 = 1; } while(0)
#define GRIP_CMD_SetAnalogMode()      do { ANSELDbits.ANSELD2 = 1; } while(0)
#define GRIP_CMD_SetDigitalMode()     do { ANSELDbits.ANSELD2 = 0; } while(0)

// get/set RD3 aliases
#define OBJ_HELD_TRIS                 TRISDbits.TRISD3
#define OBJ_HELD_LAT                  LATDbits.LATD3
#define OBJ_HELD_PORT                 PORTDbits.RD3
#define OBJ_HELD_WPU                  WPUDbits.WPUD3
#define OBJ_HELD_OD                   ODCONDbits.ODCD3
#define OBJ_HELD_ANS                  ANSELDbits.ANSELD3
#define OBJ_HELD_SetHigh()            do { LATDbits.LATD3 = 1; } while(0)
#define OBJ_HELD_SetLow()             do { LATDbits.LATD3 = 0; } while(0)
#define OBJ_HELD_Toggle()             do { LATDbits.LATD3 = ~LATDbits.LATD3; } while(0)
#define OBJ_HELD_GetValue()           PORTDbits.RD3
#define OBJ_HELD_SetDigitalInput()    do { TRISDbits.TRISD3 = 1; } while(0)
#define OBJ_HELD_SetDigitalOutput()   do { TRISDbits.TRISD3 = 0; } while(0)
#define OBJ_HELD_SetPullup()          do { WPUDbits.WPUD3 = 1; } while(0)
#define OBJ_HELD_ResetPullup()        do { WPUDbits.WPUD3 = 0; } while(0)
#define OBJ_HELD_SetPushPull()        do { ODCONDbits.ODCD3 = 0; } while(0)
#define OBJ_HELD_SetOpenDrain()       do { ODCONDbits.ODCD3 = 1; } while(0)
#define OBJ_HELD_SetAnalogMode()      do { ANSELDbits.ANSELD3 = 1; } while(0)
#define OBJ_HELD_SetDigitalMode()     do { ANSELDbits.ANSELD3 = 0; } while(0)

// get/set RD4 aliases
#define ARM_IN_POS_TRIS                 TRISDbits.TRISD4
#define ARM_IN_POS_LAT                  LATDbits.LATD4
#define ARM_IN_POS_PORT                 PORTDbits.RD4
#define ARM_IN_POS_WPU                  WPUDbits.WPUD4
#define ARM_IN_POS_OD                   ODCONDbits.ODCD4
#define ARM_IN_POS_ANS                  ANSELDbits.ANSELD4
#define ARM_IN_POS_SetHigh()            do { LATDbits.LATD4 = 1; } while(0)
#define ARM_IN_POS_SetLow()             do { LATDbits.LATD4 = 0; } while(0)
#define ARM_IN_POS_Toggle()             do { LATDbits.LATD4 = ~LATDbits.LATD4; } while(0)
#define ARM_IN_POS_GetValue()           PORTDbits.RD4
#define ARM_IN_POS_SetDigitalInput()    do { TRISDbits.TRISD4 = 1; } while(0)
#define ARM_IN_POS_SetDigitalOutput()   do { TRISDbits.TRISD4 = 0; } while(0)
#define ARM_IN_POS_SetPullup()          do { WPUDbits.WPUD4 = 1; } while(0)
#define ARM_IN_POS_ResetPullup()        do { WPUDbits.WPUD4 = 0; } while(0)
#define ARM_IN_POS_SetPushPull()        do { ODCONDbits.ODCD4 = 0; } while(0)
#define ARM_IN_POS_SetOpenDrain()       do { ODCONDbits.ODCD4 = 1; } while(0)
#define ARM_IN_POS_SetAnalogMode()      do { ANSELDbits.ANSELD4 = 1; } while(0)
#define ARM_IN_POS_SetDigitalMode()     do { ANSELDbits.ANSELD4 = 0; } while(0)

// get/set RE0 aliases
#define LED_DBG_TRIS                 TRISEbits.TRISE0
#define LED_DBG_LAT                  LATEbits.LATE0
#define LED_DBG_PORT                 PORTEbits.RE0
#define LED_DBG_WPU                  WPUEbits.WPUE0
#define LED_DBG_OD                   ODCONEbits.ODCE0
#define LED_DBG_ANS                  ANSELEbits.ANSELE0
#define LED_DBG_SetHigh()            do { LATEbits.LATE0 = 1; } while(0)
#define LED_DBG_SetLow()             do { LATEbits.LATE0 = 0; } while(0)
#define LED_DBG_Toggle()             do { LATEbits.LATE0 = ~LATEbits.LATE0; } while(0)
#define LED_DBG_GetValue()           PORTEbits.RE0
#define LED_DBG_SetDigitalInput()    do { TRISEbits.TRISE0 = 1; } while(0)
#define LED_DBG_SetDigitalOutput()   do { TRISEbits.TRISE0 = 0; } while(0)
#define LED_DBG_SetPullup()          do { WPUEbits.WPUE0 = 1; } while(0)
#define LED_DBG_ResetPullup()        do { WPUEbits.WPUE0 = 0; } while(0)
#define LED_DBG_SetPushPull()        do { ODCONEbits.ODCE0 = 0; } while(0)
#define LED_DBG_SetOpenDrain()       do { ODCONEbits.ODCE0 = 1; } while(0)
#define LED_DBG_SetAnalogMode()      do { ANSELEbits.ANSELE0 = 1; } while(0)
#define LED_DBG_SetDigitalMode()     do { ANSELEbits.ANSELE0 = 0; } while(0)

// get/set RE1 aliases
#define BTN_DBG_TRIS                 TRISEbits.TRISE1
#define BTN_DBG_LAT                  LATEbits.LATE1
#define BTN_DBG_PORT                 PORTEbits.RE1
#define BTN_DBG_WPU                  WPUEbits.WPUE1
#define BTN_DBG_OD                   ODCONEbits.ODCE1
#define BTN_DBG_ANS                  ANSELEbits.ANSELE1
#define BTN_DBG_SetHigh()            do { LATEbits.LATE1 = 1; } while(0)
#define BTN_DBG_SetLow()             do { LATEbits.LATE1 = 0; } while(0)
#define BTN_DBG_Toggle()             do { LATEbits.LATE1 = ~LATEbits.LATE1; } while(0)
#define BTN_DBG_GetValue()           PORTEbits.RE1
#define BTN_DBG_SetDigitalInput()    do { TRISEbits.TRISE1 = 1; } while(0)
#define BTN_DBG_SetDigitalOutput()   do { TRISEbits.TRISE1 = 0; } while(0)
#define BTN_DBG_SetPullup()          do { WPUEbits.WPUE1 = 1; } while(0)
#define BTN_DBG_ResetPullup()        do { WPUEbits.WPUE1 = 0; } while(0)
#define BTN_DBG_SetPushPull()        do { ODCONEbits.ODCE1 = 0; } while(0)
#define BTN_DBG_SetOpenDrain()       do { ODCONEbits.ODCE1 = 1; } while(0)
#define BTN_DBG_SetAnalogMode()      do { ANSELEbits.ANSELE1 = 1; } while(0)
#define BTN_DBG_SetDigitalMode()     do { ANSELEbits.ANSELE1 = 0; } while(0)

// get/set RF0 aliases
#define IO_RF0_TRIS                 TRISFbits.TRISF0
#define IO_RF0_LAT                  LATFbits.LATF0
#define IO_RF0_PORT                 PORTFbits.RF0
#define IO_RF0_WPU                  WPUFbits.WPUF0
#define IO_RF0_OD                   ODCONFbits.ODCF0
#define IO_RF0_ANS                  ANSELFbits.ANSELF0
#define IO_RF0_SetHigh()            do { LATFbits.LATF0 = 1; } while(0)
#define IO_RF0_SetLow()             do { LATFbits.LATF0 = 0; } while(0)
#define IO_RF0_Toggle()             do { LATFbits.LATF0 = ~LATFbits.LATF0; } while(0)
#define IO_RF0_GetValue()           PORTFbits.RF0
#define IO_RF0_SetDigitalInput()    do { TRISFbits.TRISF0 = 1; } while(0)
#define IO_RF0_SetDigitalOutput()   do { TRISFbits.TRISF0 = 0; } while(0)
#define IO_RF0_SetPullup()          do { WPUFbits.WPUF0 = 1; } while(0)
#define IO_RF0_ResetPullup()        do { WPUFbits.WPUF0 = 0; } while(0)
#define IO_RF0_SetPushPull()        do { ODCONFbits.ODCF0 = 0; } while(0)
#define IO_RF0_SetOpenDrain()       do { ODCONFbits.ODCF0 = 1; } while(0)
#define IO_RF0_SetAnalogMode()      do { ANSELFbits.ANSELF0 = 1; } while(0)
#define IO_RF0_SetDigitalMode()     do { ANSELFbits.ANSELF0 = 0; } while(0)

// get/set RF1 aliases
#define IO_RF1_TRIS                 TRISFbits.TRISF1
#define IO_RF1_LAT                  LATFbits.LATF1
#define IO_RF1_PORT                 PORTFbits.RF1
#define IO_RF1_WPU                  WPUFbits.WPUF1
#define IO_RF1_OD                   ODCONFbits.ODCF1
#define IO_RF1_ANS                  ANSELFbits.ANSELF1
#define IO_RF1_SetHigh()            do { LATFbits.LATF1 = 1; } while(0)
#define IO_RF1_SetLow()             do { LATFbits.LATF1 = 0; } while(0)
#define IO_RF1_Toggle()             do { LATFbits.LATF1 = ~LATFbits.LATF1; } while(0)
#define IO_RF1_GetValue()           PORTFbits.RF1
#define IO_RF1_SetDigitalInput()    do { TRISFbits.TRISF1 = 1; } while(0)
#define IO_RF1_SetDigitalOutput()   do { TRISFbits.TRISF1 = 0; } while(0)
#define IO_RF1_SetPullup()          do { WPUFbits.WPUF1 = 1; } while(0)
#define IO_RF1_ResetPullup()        do { WPUFbits.WPUF1 = 0; } while(0)
#define IO_RF1_SetPushPull()        do { ODCONFbits.ODCF1 = 0; } while(0)
#define IO_RF1_SetOpenDrain()       do { ODCONFbits.ODCF1 = 1; } while(0)
#define IO_RF1_SetAnalogMode()      do { ANSELFbits.ANSELF1 = 1; } while(0)
#define IO_RF1_SetDigitalMode()     do { ANSELFbits.ANSELF1 = 0; } while(0)

/**
 * @ingroup  pinsdriver
 * @brief GPIO and peripheral I/O initialization
 * @param none
 * @return none
 */
void PIN_MANAGER_Initialize (void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt on Change Handling routine
 * @param none
 * @return none
 */
void PIN_MANAGER_IOC(void);


#endif // PINS_H
/**
 End of File
*/
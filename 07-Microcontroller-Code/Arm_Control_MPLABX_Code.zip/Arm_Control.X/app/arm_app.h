/*
 * arm_app.h
 * Team pick-and-place state machine for the Arm Motion Control board.
 */
#ifndef ARM_APP_H
#define ARM_APP_H

#include <stdint.h>

typedef enum
{
    APP_IDLE = 0,       /* wait for SAFE_OK = 1 and a new RUN_REQ = 1  */
    APP_MOVE_TO_PICK,   /* forward PWM for the move time, then settle  */
    APP_WAIT_GRIP,      /* ARM_IN_POS = 1, GRIP_CMD = 1, wait OBJ_HELD */
    APP_REOPEN,         /* grip timed out: GRIP_CMD = 0, then retry    */
    APP_PAUSED,         /* object held, RUN_REQ = 0: wait before move  */
    APP_MOVE_TO_PLACE,  /* reverse PWM for the same time, then settle  */
    APP_RELEASE,        /* ARM_IN_POS = 1, GRIP_CMD = 0, wait release  */
    APP_DONE,           /* released: hold the outputs, then repeat     */
    APP_STOP,           /* SAFE_OK = 0: both PWM 0 %                   */
    APP_FAULT           /* grip or release failed: motor off           */
} app_state_t;

void        App_Enter(void);         /* safe start: everything off     */
void        App_Task1ms(void);
app_state_t App_State(void);
uint16_t    App_Cycles(void);

#endif /* ARM_APP_H */
